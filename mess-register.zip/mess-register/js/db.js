// Data layer. app.js only talks to window.DB, so the storage can be swapped
// without touching the screens. Two backends: browser demo storage and Supabase.
(function () {
  "use strict";
  const cfg = window.MESS_CONFIG;
  const configured = Boolean(cfg.SUPABASE_URL && cfg.SUPABASE_ANON_KEY);

  const uid = () =>
    window.crypto && crypto.randomUUID
      ? crypto.randomUUID()
      : Date.now().toString(36) + Math.random().toString(16).slice(2);
  const byRoll = (a, b) => a.roll_no.localeCompare(b.roll_no, undefined, { numeric: true });

  // ---------- Demo backend (localStorage) ----------
  const KEY = "mess-register-demo-v1";
  const read = () => {
    try {
      return JSON.parse(localStorage.getItem(KEY)) || { students: [], logs: [] };
    } catch (e) {
      return { students: [], logs: [] };
    }
  };
  const write = (d) => {
    try {
      localStorage.setItem(KEY, JSON.stringify(d));
    } catch (e) {
      throw new Error("This browser blocked saving data (private mode or storage full).");
    }
  };

  const demo = {
    mode: "demo",
    async user() { return { email: "demo" }; },
    async signIn() {},
    async signOut() {},
    async listStudents() { return read().students.sort(byRoll); },
    async saveStudent(s) {
      const d = read();
      const clash = d.students.find((x) => x.roll_no === s.roll_no && x.id !== s.id);
      if (clash) throw new Error("That roll number already exists.");
      const row = { roll_no: s.roll_no, name: s.name, diet: s.diet,
                    daily_requirement: s.daily_requirement, notes: s.notes || null };
      if (s.id) {
        const i = d.students.findIndex((x) => x.id === s.id);
        if (i >= 0) d.students[i] = { ...d.students[i], ...row };
      } else {
        d.students.push({ id: uid(), created_at: new Date().toISOString(), ...row });
      }
      write(d);
    },
    async deleteStudent(id) {
      const d = read();
      d.students = d.students.filter((s) => s.id !== id);
      d.logs = d.logs.filter((l) => l.student_id !== id);
      write(d);
    },
    async importStudents(rows) {
      const d = read();
      rows.forEach((r) => {
        const existing = d.students.find((s) => s.roll_no === r.roll_no);
        if (existing) Object.assign(existing, r);
        else d.students.push({ id: uid(), created_at: new Date().toISOString(), ...r });
      });
      write(d);
    },
    async listLogs(from, to) {
      return read().logs.filter((l) => l.log_date >= from && l.log_date <= to);
    },
    async addLog(l) {
      const d = read();
      d.logs.push({ id: uid(), created_at: new Date().toISOString(), note: null, ...l });
      write(d);
    },
    async deleteLog(id) {
      const d = read();
      d.logs = d.logs.filter((l) => l.id !== id);
      write(d);
    }
  };

  // ---------- Supabase backend ----------
  function friendly(error) {
    if (error && error.code === "23505") return new Error("That roll number already exists.");
    return new Error((error && error.message) || "Something went wrong.");
  }

  function makeRemote() {
    const sb = window.supabase.createClient(cfg.SUPABASE_URL, cfg.SUPABASE_ANON_KEY);
    return {
      mode: "supabase",
      async user() {
        const { data } = await sb.auth.getSession();
        return data.session ? data.session.user : null;
      },
      async signIn(email, password) {
        const { error } = await sb.auth.signInWithPassword({ email, password });
        if (error) throw friendly(error);
      },
      async signOut() { await sb.auth.signOut(); },
      async listStudents() {
        const { data, error } = await sb.from("students").select("*").order("roll_no");
        if (error) throw friendly(error);
        return data.sort(byRoll);
      },
      async saveStudent(s) {
        const row = { roll_no: s.roll_no, name: s.name, diet: s.diet,
                      daily_requirement: s.daily_requirement, notes: s.notes || null };
        const { error } = s.id
          ? await sb.from("students").update(row).eq("id", s.id)
          : await sb.from("students").insert(row);
        if (error) throw friendly(error);
      },
      async deleteStudent(id) {
        const { error } = await sb.from("students").delete().eq("id", id);
        if (error) throw friendly(error);
      },
      async importStudents(rows) {
        const { error } = await sb.from("students").upsert(rows, { onConflict: "roll_no" });
        if (error) throw friendly(error);
      },
      async listLogs(from, to) {
        const size = 1000;
        let all = [];
        for (let start = 0; ; start += size) {
          const { data, error } = await sb
            .from("meal_logs").select("*")
            .gte("log_date", from).lte("log_date", to)
            .order("created_at", { ascending: false }).order("id")
            .range(start, start + size - 1);
          if (error) throw friendly(error);
          all = all.concat(data);
          if (data.length < size) break;
        }
        return all;
      },
      async addLog(l) {
        const { error } = await sb.from("meal_logs").insert(l);
        if (error) throw friendly(error);
      },
      async deleteLog(id) {
        const { error } = await sb.from("meal_logs").delete().eq("id", id);
        if (error) throw friendly(error);
      }
    };
  }

  if (!configured) {
    window.DB = demo;
  } else if (window.supabase && window.supabase.createClient) {
    window.DB = makeRemote();
  } else {
    window.DB = null; // configured, but the Supabase library did not load
  }
})();
