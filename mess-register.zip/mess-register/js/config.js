// Mess register settings.
//
// DEMO MODE: leave SUPABASE_URL and SUPABASE_ANON_KEY empty. Data is saved only
// in this browser, which is good for trying the app out.
//
// REAL USE: paste your Supabase project URL and anon (public) key here.
// The anon key is meant to be public; your data is protected by the login and
// the row-level security rules in supabase/schema.sql.
// NEVER paste the "service_role" key into this file.
window.MESS_CONFIG = {
  SUPABASE_URL: "",
  SUPABASE_ANON_KEY: "",

  MEALS: ["breakfast", "lunch", "snacks", "dinner"],
  DEFAULT_REQUIREMENT: 4,   // portions per day for new students
  LOW_THRESHOLD: 0.7,       // below 70% of requirement is flagged "Below"
  HIGH_THRESHOLD: 1.2       // above 120% of requirement is flagged "Above"
};
