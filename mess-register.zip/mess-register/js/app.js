// Mess register: screens and behaviour. Storage lives in db.js.
(function () {
  "use strict";
  const cfg = window.MESS_CONFIG;
  const DB = window.DB;
  const MEALS = cfg.MEALS;
  const DIETS = { veg: "Veg", "non-veg": "Non-veg", egg: "Egg", jain: "Jain", special: "Special" };
  const MARK = { veg: "veg", "non-veg": "nonveg", egg: "egg", jain: "veg", special: "special" };

  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
  const esc = (s) =>
    String(s == null ? "" : s).replace(/[&<>"']/g, (c) =>
      ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const pad = (n) => String(n).padStart(2, "0");
  const ymd = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  const today = () => ymd(new Date());
  const fmt = (n) => String(Math.round(Number(n) * 100) / 100);
  const cap = (s) => s.charAt(0).toUpperCase() + s.slice(1);
  const timeOf = (iso) =>
    iso ? new Date(iso).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }) : "";
  const guessMeal = () => {
    const h = new Date().getHours();
    return h < 10 ? "breakfast" : h < 15 ? "lunch" : h < 18 ? "snacks" : "dinner";
  };
  const dietHtml = (d) =>
    `<span class="diet"><span class="mark mark-${MARK[d] || "special"}" aria-hidden="true"></span>${esc(DIETS[d] || d)}</span>`;

  const state = { students: [], todayLogs: [], selected: null, hits: [],
                  meal: guessMeal(), editingId: null, reportLogs: [], reportRange: null };

  // ---------- helpers ----------
  let toastTimer;
  function toast(msg, bad) {
    const t = $("#toast");
    t.textContent = msg;
    t.className = "toast show" + (bad ? " bad" : "");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => { t.className = "toast"; }, 3400);
  }
  async function safe(fn) {
    try { await fn(); } catch (e) { console.error(e); toast(e.message || "Something went wrong.", true); }
  }
  async function loadStudents() { state.students = await DB.listStudents(); }
  async function loadToday() { state.todayLogs = await DB.listLogs(today(), today()); }

  // ---------- log meals ----------
  function mealsToday(studentId) {
    const by = {};
    state.todayLogs.filter((l) => l.student_id === studentId)
      .forEach((l) => { by[l.meal] = (by[l.meal] || 0) + Number(l.portions); });
    return by;
  }

  function renderMatches() {
    const raw = $("#q").value.trim();
    const q = raw.toLowerCase();
    const ul = $("#matches");
    if (!q) { state.hits = []; ul.innerHTML = ""; return; }
    state.hits = state.students
      .filter((s) => s.roll_no.toLowerCase().includes(q) || s.name.toLowerCase().includes(q))
      .sort((a, b) =>
        (b.roll_no.toLowerCase() === q) - (a.roll_no.toLowerCase() === q) ||
        a.roll_no.localeCompare(b.roll_no, undefined, { numeric: true }))
      .slice(0, 6);
    ul.innerHTML = state.hits.length
      ? state.hits.map((s) =>
          `<li><button type="button" data-id="${esc(s.id)}"><span class="roll">${esc(s.roll_no)}</span><span>${esc(s.name)}</span>${dietHtml(s.diet)}</button></li>`).join("")
      : `<li class="none">No student matches "${esc(raw)}".</li>`;
  }

  function selectStudent(s) {
    state.selected = s;
    $("#q").value = "";
    renderMatches();
    renderEntry();
    const p = $("#portions");
    if (p) { p.focus(); p.select(); }
  }

  function renderEntry() {
    const box = $("#entry");
    const s = state.selected;
    if (!s) {
      box.innerHTML = state.students.length
        ? `<p class="hint">Type a roll number and press Enter. Press Enter again to log one portion.</p>`
        : `<p class="hint">Add students in the Students tab first.</p>`;
      return;
    }
    const by = mealsToday(s.id);
    const eaten = Object.values(by).reduce((a, b) => a + b, 0);
    const req = Number(s.daily_requirement) || 0;
    const pct = req ? Math.min(100, Math.round((eaten / req) * 100)) : 0;
    const soFar = Object.entries(by).map(([m, p]) => `${m} ${fmt(p)}`).join(", ");
    box.innerHTML = `
      <form id="logForm" class="card student">
        <div class="student-head">
          <div>
            <div class="name">${esc(s.name)}</div>
            <div class="sub"><span class="roll">${esc(s.roll_no)}</span>${dietHtml(s.diet)}</div>
          </div>
          <button type="button" class="ghost" id="clearSel">Change</button>
        </div>
        ${s.notes ? `<p class="note">${esc(s.notes)}</p>` : ""}
        <div class="meter">
          <div class="track" role="img" aria-label="${fmt(eaten)} of ${fmt(req)} portions eaten today">
            <i class="${eaten >= req ? "met" : ""}" style="width:${pct}%"></i>
          </div>
          <p>${fmt(eaten)} of ${fmt(req)} portions today${soFar ? ` (${esc(soFar)})` : ""}</p>
        </div>
        <fieldset class="meals">
          <legend>Meal</legend>
          ${MEALS.map((m) => `<label class="chip"><input type="radio" name="meal" value="${m}" ${m === state.meal ? "checked" : ""}><span>${cap(m)}</span></label>`).join("")}
        </fieldset>
        <label for="portions">Portions eaten</label>
        <div class="stepper">
          <button type="button" data-step="-0.5" aria-label="Half a portion less">&minus;</button>
          <input id="portions" type="number" inputmode="decimal" min="0.5" step="0.5" value="1" required>
          <button type="button" data-step="0.5" aria-label="Half a portion more">+</button>
        </div>
        <button class="btn primary" type="submit">Log meal</button>
      </form>`;
  }

  function renderToday() {
    const byId = new Map(state.students.map((s) => [s.id, s]));
    const rows = [...state.todayLogs].sort((a, b) => (b.created_at || "").localeCompare(a.created_at || ""));
    const total = rows.reduce((a, l) => a + Number(l.portions), 0);
    $("#todayCount").textContent = rows.length ? `${rows.length} entries, ${fmt(total)} portions` : "";
    $("#todayRows").innerHTML = rows.length
      ? rows.map((l) => {
          const s = byId.get(l.student_id) || {};
          return `<tr><td>${esc(timeOf(l.created_at))}</td><td class="roll">${esc(s.roll_no || "?")}</td><td>${esc(s.name || "Deleted student")}</td><td>${esc(cap(l.meal))}</td><td class="num">${fmt(l.portions)}</td><td><button class="link danger" data-del="${esc(l.id)}">Remove</button></td></tr>`;
        }).join("")
      : `<tr><td colspan="6" class="empty">Nothing logged yet today.</td></tr>`;
  }

  function wireLog() {
    $("#q").addEventListener("input", renderMatches);
    $("#q").addEventListener("keydown", (e) => {
      if (e.key === "Enter") {
        e.preventDefault();
        if (state.hits[0]) selectStudent(state.hits[0]);
      }
    });
    $("#matches").addEventListener("click", (e) => {
      const b = e.target.closest("button[data-id]");
      if (!b) return;
      const s = state.students.find((x) => x.id === b.dataset.id);
      if (s) selectStudent(s);
    });
    const entry = $("#entry");
    entry.addEventListener("click", (e) => {
      const step = e.target.closest("button[data-step]");
      if (step) {
        const p = $("#portions");
        p.value = Math.max(0.5, (parseFloat(p.value) || 0) + parseFloat(step.dataset.step));
        return;
      }
      if (e.target.id === "clearSel") {
        state.selected = null;
        renderEntry();
        $("#q").focus();
      }
    });
    entry.addEventListener("change", (e) => {
      if (e.target.name === "meal") state.meal = e.target.value;
    });
    entry.addEventListener("submit", (e) => {
      e.preventDefault();
      safe(async () => {
        const s = state.selected;
        const portions = parseFloat($("#portions").value);
        if (!s) return;
        if (!(portions > 0)) throw new Error("Enter the portions eaten (0.5 or more).");
        await DB.addLog({ student_id: s.id, log_date: today(), meal: state.meal, portions });
        await loadToday();
        toast(`Logged ${fmt(portions)} portion${portions === 1 ? "" : "s"} of ${state.meal} for ${s.name}.`);
        state.selected = null;
        renderEntry();
        renderToday();
        $("#q").focus();
      });
    });
    $("#todayRows").addEventListener("click", (e) => {
      const b = e.target.closest("button[data-del]");
      if (!b || !confirm("Remove this entry?")) return;
      safe(async () => {
        await DB.deleteLog(b.dataset.del);
        await loadToday();
        renderToday();
        if (state.selected) renderEntry();
        toast("Entry removed.");
      });
    });
  }

  // ---------- students ----------
  function renderStudents() {
    const f = $("#sq").value.trim().toLowerCase();
    const out = $("#studentList");
    if (!state.students.length) {
      out.innerHTML = `<div class="empty-state"><p>No students yet.</p>
        <p>Add one, or import a CSV with the columns roll_no, name, diet, daily_requirement, notes.</p>
        ${DB.mode === "demo" ? `<button class="btn" id="loadSample" type="button">Load 6 sample students</button>` : ""}</div>`;
      return;
    }
    const list = state.students.filter((s) =>
      !f || s.roll_no.toLowerCase().includes(f) || s.name.toLowerCase().includes(f));
    out.innerHTML = `<div class="tablewrap"><table>
      <thead><tr><th>Roll</th><th>Name</th><th>Diet</th><th class="num">Portions/day</th><th>Notes</th><th><span class="sr">Actions</span></th></tr></thead>
      <tbody>${list.length ? list.map((s) => `<tr>
        <td class="roll">${esc(s.roll_no)}</td><td>${esc(s.name)}</td><td>${dietHtml(s.diet)}</td>
        <td class="num">${fmt(s.daily_requirement)}</td><td>${esc(s.notes || "")}</td>
        <td><button class="link" data-edit="${esc(s.id)}">Edit</button><button class="link danger" data-delstudent="${esc(s.id)}">Delete</button></td></tr>`).join("")
        : `<tr><td colspan="6" class="empty">No student matches that filter.</td></tr>`}</tbody></table></div>`;
  }

  function openStudentForm(s) {
    state.editingId = s ? s.id : null;
    $("#studentForm").hidden = false;
    $("#sf-title").textContent = s ? "Edit student" : "Add student";
    $("#sf-roll").value = s ? s.roll_no : "";
    $("#sf-name").value = s ? s.name : "";
    $("#sf-diet").value = s ? s.diet : "veg";
    $("#sf-req").value = s ? s.daily_requirement : cfg.DEFAULT_REQUIREMENT;
    $("#sf-notes").value = s ? s.notes || "" : "";
    $("#sf-roll").focus();
  }

  const SAMPLE = [
    ["S101", "Ananya Das", "veg", 4, ""],
    ["S102", "Rohit Sahu", "non-veg", 5, ""],
    ["S103", "Priya Nayak", "egg", 4, ""],
    ["S104", "Sourav Behera", "veg", 4.5, ""],
    ["S105", "Meera Jain", "jain", 3.5, "No onion or garlic"],
    ["S106", "Imran Khan", "special", 4, "Low-oil meals"]
  ].map(([roll_no, name, diet, daily_requirement, notes]) =>
    ({ roll_no, name, diet, daily_requirement, notes: notes || null }));

  function parseCsv(text) {
    if (text.charCodeAt(0) === 0xfeff) text = text.slice(1);
    const rows = [];
    let row = [], cur = "", q = false;
    for (let i = 0; i < text.length; i++) {
      const c = text[i];
      if (q) {
        if (c === '"') { if (text[i + 1] === '"') { cur += '"'; i++; } else q = false; }
        else cur += c;
      } else if (c === '"') q = true;
      else if (c === ",") { row.push(cur); cur = ""; }
      else if (c === "\n") { row.push(cur); rows.push(row); row = []; cur = ""; }
      else if (c !== "\r") cur += c;
    }
    if (cur !== "" || row.length) { row.push(cur); rows.push(row); }
    return rows.filter((r) => r.some((c) => c.trim() !== ""));
  }

  function normDiet(v) {
    const x = String(v || "").trim().toLowerCase().replace(/[\s_]+/g, "-");
    if (x === "nonveg" || x === "non-vegetarian") return "non-veg";
    if (x === "vegetarian") return "veg";
    return DIETS[x] ? x : null;
  }

  function parseStudentsCsv(text) {
    const rows = parseCsv(text);
    if (!rows.length) return { rows: [], skipped: 0 };
    const head = rows[0].map((h) => h.trim().toLowerCase());
    const ix = (n) => head.indexOf(n);
    if (ix("roll_no") < 0 || ix("name") < 0) return { rows: [], skipped: rows.length - 1 };
    const out = new Map();
    let skipped = 0;
    rows.slice(1).forEach((r) => {
      const roll_no = (r[ix("roll_no")] || "").trim();
      const name = (r[ix("name")] || "").trim();
      const diet = normDiet(ix("diet") >= 0 ? r[ix("diet")] : "");
      let req = ix("daily_requirement") >= 0 ? parseFloat(r[ix("daily_requirement")]) : NaN;
      if (!(req > 0)) req = cfg.DEFAULT_REQUIREMENT;
      const notes = ix("notes") >= 0 ? (r[ix("notes")] || "").trim() : "";
      if (!roll_no || !name || !diet) { skipped++; return; }
      out.set(roll_no, { roll_no, name, diet, daily_requirement: req, notes: notes || null });
    });
    return { rows: Array.from(out.values()), skipped };
  }

  function wireStudents() {
    $("#sq").addEventListener("input", renderStudents);
    $("#addStudent").addEventListener("click", () => openStudentForm(null));
    $("#sf-cancel").addEventListener("click", () => { $("#studentForm").hidden = true; });
    $("#importBtn").addEventListener("click", () => $("#importFile").click());
    $("#studentForm").addEventListener("submit", (e) => {
      e.preventDefault();
      safe(async () => {
        const req = parseFloat($("#sf-req").value);
        if (!(req > 0)) throw new Error("Daily requirement must be more than 0.");
        await DB.saveStudent({
          id: state.editingId,
          roll_no: $("#sf-roll").value.trim(),
          name: $("#sf-name").value.trim(),
          diet: $("#sf-diet").value,
          daily_requirement: req,
          notes: $("#sf-notes").value.trim()
        });
        await loadStudents();
        $("#studentForm").hidden = true;
        renderStudents();
        renderEntry();
        toast("Student saved.");
      });
    });
    $("#studentList").addEventListener("click", (e) => {
      const edit = e.target.closest("[data-edit]");
      const del = e.target.closest("[data-delstudent]");
      if (e.target.id === "loadSample") {
        safe(async () => {
          await DB.importStudents(SAMPLE);
          await loadStudents();
          renderStudents();
          toast("Sample students added.");
        });
      } else if (edit) {
        openStudentForm(state.students.find((s) => s.id === edit.dataset.edit));
      } else if (del) {
        const s = state.students.find((x) => x.id === del.dataset.delstudent);
        if (!s || !confirm(`Delete ${s.name} and all of their meal records?`)) return;
        safe(async () => {
          await DB.deleteStudent(s.id);
          if (state.selected && state.selected.id === s.id) state.selected = null;
          await Promise.all([loadStudents(), loadToday()]);
          renderStudents(); renderEntry(); renderToday();
          toast("Student deleted.");
        });
      }
    });
    $("#importFile").addEventListener("change", (e) => {
      const file = e.target.files[0];
      e.target.value = "";
      if (!file) return;
      safe(async () => {
        const { rows, skipped } = parseStudentsCsv(await file.text());
        if (!rows.length) {
          throw new Error("No valid rows found. Columns needed: roll_no, name, diet, daily_requirement, notes.");
        }
        await DB.importStudents(rows);
        await loadStudents();
        renderStudents();
        toast(`Imported ${rows.length} students${skipped ? `, skipped ${skipped} with missing or invalid details` : ""}.`);
      });
    });
  }

  // ---------- reports ----------
  const daysBetween = (from, to) =>
    Math.round((new Date(to + "T00:00:00") - new Date(from + "T00:00:00")) / 86400000) + 1;

  async function runReport() {
    const from = $("#rfrom").value, to = $("#rto").value;
    const out = $("#reportOut");
    if (!from || !to || from > to) {
      out.innerHTML = `<p class="hint">Choose a start date on or before the end date.</p>`;
      return;
    }
    const logs = await DB.listLogs(from, to);
    state.reportLogs = logs;
    state.reportRange = { from, to };
    const days = daysBetween(from, to);

    const perMeal = Object.fromEntries(MEALS.map((m) => [m, 0]));
    const per = new Map();
    let total = 0;
    logs.forEach((l) => {
      const p = Number(l.portions);
      total += p;
      perMeal[l.meal] = (perMeal[l.meal] || 0) + p;
      const r = per.get(l.student_id) || { portions: 0, dates: new Set() };
      r.portions += p;
      r.dates.add(l.log_date);
      per.set(l.student_id, r);
    });

    const rows = state.students.map((s) => {
      const r = per.get(s.id) || { portions: 0, dates: new Set() };
      const expected = Number(s.daily_requirement) * days;
      const ratio = expected ? r.portions / expected : 0;
      return { s, portions: r.portions, days: r.dates.size, expected, ratio };
    }).sort((a, b) => a.ratio - b.ratio);

    const status = (ratio) =>
      ratio < cfg.LOW_THRESHOLD ? ["low", "Below requirement"]
      : ratio > cfg.HIGH_THRESHOLD ? ["high", "Above requirement"]
      : ["ok", "On track"];

    out.innerHTML = `
      <div class="stats">
        <div class="card stat"><strong>${logs.length}</strong><span>meal entries</span></div>
        <div class="card stat"><strong>${per.size}</strong><span>students served</span></div>
        <div class="card stat"><strong>${fmt(total)}</strong><span>portions served</span></div>
      </div>
      <div class="tablewrap"><table>
        <thead><tr>${MEALS.map((m) => `<th class="num">${cap(m)}</th>`).join("")}</tr></thead>
        <tbody><tr>${MEALS.map((m) => `<td class="num">${fmt(perMeal[m] || 0)}</td>`).join("")}</tr></tbody>
      </table></div>
      <h2>Each student against their requirement</h2>
      <div class="tablewrap"><table>
        <thead><tr><th>Roll</th><th>Name</th><th>Diet</th><th class="num">Days eaten</th><th class="num">Portions</th><th class="num">Expected</th><th class="num">Of requirement</th><th>Status</th></tr></thead>
        <tbody>${rows.length ? rows.map(({ s, portions, days: d, expected, ratio }) => {
          const [cls, label] = status(ratio);
          return `<tr><td class="roll">${esc(s.roll_no)}</td><td>${esc(s.name)}</td><td>${dietHtml(s.diet)}</td>
            <td class="num">${d} of ${days}</td><td class="num">${fmt(portions)}</td><td class="num">${fmt(expected)}</td>
            <td class="num">${Math.round(ratio * 100)}%</td><td><span class="status ${cls}">${label}</span></td></tr>`;
        }).join("") : `<tr><td colspan="8" class="empty">No students yet.</td></tr>`}</tbody>
      </table></div>
      <p class="report-note">Expected portions = daily requirement × ${days} day${days === 1 ? "" : "s"} in this range. Students with no entries show as below requirement, which also helps spot absences.</p>`;
  }

  const csvCell = (v) => {
    let s = String(v == null ? "" : v);
    if (/^[=+\-@]/.test(s)) s = "'" + s; // stop spreadsheet formula injection
    return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };

  function exportCsv() {
    const logs = state.reportLogs;
    if (!logs.length) throw new Error("Show a report that has some meal entries first.");
    const byId = new Map(state.students.map((s) => [s.id, s]));
    const lines = [["date", "time", "roll_no", "name", "diet", "meal", "portions", "note"].join(",")];
    [...logs].sort((a, b) => (a.created_at || "").localeCompare(b.created_at || "")).forEach((l) => {
      const s = byId.get(l.student_id) || {};
      lines.push([l.log_date, timeOf(l.created_at), s.roll_no, s.name, s.diet, l.meal, l.portions, l.note].map(csvCell).join(","));
    });
    const blob = new Blob([lines.join("\n")], { type: "text/csv;charset=utf-8" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = `mess-meals_${state.reportRange.from}_to_${state.reportRange.to}.csv`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 1000);
  }

  // ---------- shell ----------
  function showTab(name) {
    $$(".tab").forEach((b) => {
      if (b.dataset.tab === name) b.setAttribute("aria-current", "page");
      else b.removeAttribute("aria-current");
    });
    $$(".panel").forEach((p) => { p.hidden = p.id !== "tab-" + name; });
    if (name === "students") renderStudents();
    if (name === "reports") safe(runReport);
    if (name === "log") $("#q").focus();
  }

  async function start() {
    $("#login").hidden = true;
    $("#app").hidden = false;
    if (DB.mode === "supabase") $("#signout").hidden = false;
    const t = new Date(), f = new Date();
    f.setDate(f.getDate() - 6);
    $("#rfrom").value = ymd(f);
    $("#rto").value = ymd(t);
    await safe(async () => {
      await Promise.all([loadStudents(), loadToday()]);
      renderEntry();
      renderToday();
    });
    $("#q").focus();
  }

  function wireShell() {
    $$(".tab").forEach((b) => b.addEventListener("click", () => showTab(b.dataset.tab)));
    $("#runReport").addEventListener("click", () => safe(runReport));
    $("#exportLogs").addEventListener("click", () => safe(async () => exportCsv()));
    $("#signout").addEventListener("click", async () => { await DB.signOut(); location.reload(); });
    $("#loginForm").addEventListener("submit", async (e) => {
      e.preventDefault();
      const err = $("#loginError");
      err.hidden = true;
      try {
        await DB.signIn($("#email").value.trim(), $("#password").value);
        await start();
      } catch (ex) {
        err.textContent = ex.message || "Could not sign in.";
        err.hidden = false;
      }
    });
    wireLog();
    wireStudents();
  }

  async function boot() {
    const banner = $("#banner");
    if (!DB) {
      banner.className = "banner error";
      banner.textContent = "Supabase is set up in js/config.js but its library did not load. Check your internet connection and reload.";
      banner.hidden = false;
      return;
    }
    wireShell();
    if (DB.mode === "demo") {
      banner.textContent = "Demo mode: data is saved only in this browser. Add your Supabase details in js/config.js to share data between devices.";
      banner.hidden = false;
      await start();
      return;
    }
    const user = await DB.user();
    if (user) await start();
    else { $("#login").hidden = false; $("#email").focus(); }
  }

  document.addEventListener("DOMContentLoaded", () => safe(boot));
})();
