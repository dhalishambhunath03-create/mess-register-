-- Mess register: database schema for Supabase
-- Run this once in Supabase: SQL Editor > New query > paste > Run.

create table public.students (
  id uuid primary key default gen_random_uuid(),
  roll_no text not null unique,
  name text not null,
  diet text not null check (diet in ('veg', 'non-veg', 'egg', 'jain', 'special')),
  daily_requirement numeric(4,1) not null default 4 check (daily_requirement > 0),  -- portions per day
  notes text,                                                                      -- e.g. "no onion or garlic"
  created_at timestamptz not null default now()
);

create table public.meal_logs (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references public.students (id) on delete cascade,
  log_date date not null default current_date,
  meal text not null check (meal in ('breakfast', 'lunch', 'snacks', 'dinner')),
  portions numeric(4,1) not null check (portions > 0),
  note text,
  created_by uuid default auth.uid(),
  created_at timestamptz not null default now()
);

create index meal_logs_date_idx on public.meal_logs (log_date);
create index meal_logs_student_idx on public.meal_logs (student_id, log_date);

-- Only signed-in mess staff can read or write. Visitors without a login get nothing.
alter table public.students enable row level security;
alter table public.meal_logs enable row level security;

create policy "Staff manage students"
  on public.students for all to authenticated
  using (true) with check (true);

create policy "Staff manage meal logs"
  on public.meal_logs for all to authenticated
  using (true) with check (true);
