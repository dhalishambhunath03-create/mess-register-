# Mess register

A small website for a hostel or college mess. Staff log which students ate, which meal, and how many portions. Each student has a diet type (veg, non-veg, egg, Jain, special) and a daily requirement in portions, and reports show who is eating below or above their requirement.

- Plain HTML, CSS and JavaScript. No build step.
- Hosted free on **GitHub Pages**.
- Data stored in **Supabase** (free tier), behind a staff login.
- Works in **demo mode** with no setup. Data then stays in your own browser only.

## Try it now

Open `index.html` in a browser, or from this folder run:

```
python3 -m http.server 8000
```

then visit http://localhost:8000. Go to **Students**, click **Load 6 sample students**, then use **Log meals**.

Fast logging: type a roll number, press Enter, press Enter again to log one portion.

## Put it on GitHub

1. Create an empty repo at https://github.com/new (for example `mess-register`).
2. In this folder:

```
git init
git add .
git commit -m "Mess register starter"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/mess-register.git
git push -u origin main
```

3. In the repo go to **Settings > Pages**, set the source to **Deploy from a branch**, choose `main` and `/ (root)`, and save. Your site appears at `https://YOUR-USERNAME.github.io/mess-register/`.

On GitHub's free plan, Pages generally needs a public repo. That is fine here, because the repo contains only code. Student data never goes in the repo.

## Save real data with Supabase

GitHub Pages cannot store data, so use Supabase as the database.

1. Create a free project at https://supabase.com.
2. Open **SQL Editor**, paste the contents of `supabase/schema.sql`, and run it. This creates the tables and makes them readable only by signed-in staff.
3. Open **Authentication > Users** and add each staff member with an email and password.
4. Open **Authentication > Sign In / Providers** (or **Settings**) and turn **off** "Allow new users to sign up", so only staff you add can get in.
5. Open **Project Settings > API**. Copy the **Project URL** and the **anon public** key into `js/config.js`.
6. Commit and push. The site now asks for a staff login and saves data to Supabase.

The anon key is designed to be public. Do not put the `service_role` key anywhere in this repo.

## Importing students

On the **Students** tab, click **Import CSV**. Columns:

```
roll_no,name,diet,daily_requirement,notes
S201,Asha Rout,veg,4,
S202,Dev Patra,non-veg,5,
S203,Rina Das,jain,3.5,No onion or garlic
```

`diet` must be one of veg, non-veg, egg, jain, special. Importing an existing roll number updates that student. Rows with a missing roll number, name or valid diet are skipped.

## How reports work

- "Portions" are what staff enter at the counter. One portion means one standard serving for your mess.
- Expected portions = the student's daily requirement x the number of days in the date range.
- Below 70% of expected shows as **Below requirement**, above 120% as **Above requirement**. Change `LOW_THRESHOLD` and `HIGH_THRESHOLD` in `js/config.js`.
- **Download CSV** exports every meal entry in the range.

## Customising

- Meals (breakfast, lunch, snacks, dinner) and defaults: `js/config.js`. If you rename meals, also update the `check` on `meal_logs.meal` in `supabase/schema.sql`.
- Calories or grams instead of portions would need a menu table and a quantity unit. The data layer in `js/db.js` is the place to extend.

## Privacy

Diet notes can reveal health information. Keep real student data in Supabase only, give logins to the staff who need them, and do not commit exports or CSV files with student details to the repo.

## Project layout

```
index.html          page structure
css/style.css       styles
js/config.js        settings and Supabase keys
js/db.js            storage (demo and Supabase)
js/app.js           screens and behaviour
supabase/schema.sql database tables and access rules
```
